package br.com.fiap.marte.model;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;


	@Entity
	public class Missao {
	
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String dataTerra;
    private String horaTerra;
    private int diasMarte;
    private float longSolar;
    private float densidadeAtm;
    private float tempMax;
    private float tempMin;
    private float pressaoAtm;
    public Missao() {
    	
   }
    @Override
    public String toString() {
        return "Missao{" +
                "id=" + id +
                ", dataTerra=" + dataTerra +
                ", horaTerra=" + horaTerra +
                ", diasMarte=" + diasMarte +
               //", hora da loucura=" + getDataInteria() +
                ", longSolar=" + longSolar +
                ", densidadeAtm=" + densidadeAtm +
                ", tempMax=" + tempMax +
                ", tempMin=" + tempMin +
                ", pressaoAtm=" + pressaoAtm +
                '}';
        
    }
    
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

   /* public LocalDateTime getDataInteria(){
        return LocalDateTime.parse(dataTerra + " " + horaTerra, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
    }*/
    
    public String getDataTerra() {
        return dataTerra;
    }
    public void setDataTerra(String dataTerra) {
        this.dataTerra = dataTerra;
    }
    public String getHoraTerra() {
        return horaTerra;
    }
    public void setHoraTerra(String horaTerra) {
        this.horaTerra = horaTerra;
    }
    public int getDiasMarte() {
        return diasMarte;
    }
    public void setDiasMarte(String diasMarte) {
        this.diasMarte = Integer.parseInt(diasMarte);
    }
    public float getLongSolar() {
        return longSolar;
    }
    public void setLongSolar(String longSolar) {
        this.longSolar = Float.parseFloat(longSolar);
    }
    public float getDensidadeAtm() {
        return densidadeAtm;
    }
    public void setDensidadeAtm(String densidadeAtm) {
        this.densidadeAtm = Float.parseFloat(densidadeAtm);
    }
    public float getTempMax() {
        return tempMax;
    }
    public void setTempMax(String tempMax) {
        this.tempMax = Float.parseFloat(tempMax);
    }
    public float getTempMin() {
        return tempMin;
    }
    public void setTempMin(String tempMin) {
        this.tempMin = Float.parseFloat(tempMin);
    }
    public float getPressaoAtm() {
        return pressaoAtm;
    }
    public void setPressaoAtm(String pressaoAtm) {
        this.pressaoAtm = Float.parseFloat(pressaoAtm);
    }
}
	
	
	