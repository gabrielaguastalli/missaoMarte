package br.com.fiap.marte;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import br.com.fiap.marte.paineis.PainelCadastro;
import br.com.fiap.marte.paineis.PainelRelatorio;

public class Interface extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private PainelCadastro abaCadastro = new PainelCadastro();
	private PainelRelatorio abaRelatorio = new PainelRelatorio();
	private JTabbedPane abas = new JTabbedPane();
	
	public static void main(String[] args) {
		new Interface().init();
		
	}
	
	private void init() {
		abas.add("Cadastro de Informa��es", abaCadastro);
		abas.add("Relat�rio de Miss�es", abaRelatorio);
		
		/*
		 * String[] colunas = {"Nome", "Idade"}; String[] dados = {"Nome", "Idade"};
		 * 
		 * } JTable tabela = new JTable(dados, colunas);
		 */
		add(abas);
		//add(tabela);
		
		
		setVisible(true);
		setSize(600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}

}
